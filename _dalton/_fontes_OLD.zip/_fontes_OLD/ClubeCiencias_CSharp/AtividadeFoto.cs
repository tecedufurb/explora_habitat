
internal class AtividadeFoto : Atividade
{
  // private RawImage foto; 
  int foto; // remover

  public AtividadeFoto(string descricao, int foto /*, RawImage foto */) : base(descricao)
  {
    // this.foto = foto;
  }
}